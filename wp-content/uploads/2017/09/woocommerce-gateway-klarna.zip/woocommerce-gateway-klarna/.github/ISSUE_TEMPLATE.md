Please submit issues and pull requests to Krokedil repo - https://github.com/krokedil/woocommerce-gateway-klarna 

### Expected behavior

-

### Actual behavior

-

### Steps to reproduce the behavior

-

### Klarna plugin version

-

### WordPress version

-

### WooCommerce version

-

### Klarna country

-
